package org.example.utils.key;

import org.example.utils.CacheObject;
import org.example.utils.Value;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Класс, описывающий ключ кэша.
 * Инкапсулирует в себе:
 * <p>
 * 1.1) Коллекции вызванных методов Mutable c их параметрами
 * <p>
 * 1.2) MAP с полями и значениями полей. Это новая вводная появилась после того как уже сделал задачу
 * <p>
 * 2) Информацию о вызванном кешируемом методе
 * <p>
 * Этот набор должен давать уникальный хэш.
 * <p>
 * Так же содержит в себе MAP кэшев со значениями и обеспечивает помпещение и извлечение значения из кеша.
 * Ко всем обрабатывает в отдельном потоке параметр "время жизни"
 */

public class CacheKey implements Runnable {
    boolean useMutableForCache;
    Map<CacheKey, Value> cache; // Это сам кеш.
    private MethodCall cacheMethodCall; // Часть ключа, формируемая вызовом функции cache с ее параметрами
    private Set<MethodCall> mutatorMethodCalls; // часть ключа - набор вызовов методов Mutator с параметрами
    private Map<Field, Object> fields;

    private final long sleepTime=100;

    public CacheKey(boolean useMutableForCache) {
        this.useMutableForCache = useMutableForCache;
    }

    private CacheKey(CacheKey stateKey) {
        if (stateKey != null) {
            if (stateKey.mutatorMethodCalls != null)
                this.mutatorMethodCalls = Set.copyOf(stateKey.mutatorMethodCalls);// При создании ключа из другого ключа. Коллекцию mutatorMethodCalls копируем
            if (stateKey.fields != null) this.fields = Map.copyOf(stateKey.fields);
            this.cacheMethodCall = stateKey.cacheMethodCall;
        }
    }

    public void setCacheMethodCall(MethodCall cacheKey) {
        cacheMethodCall = cacheKey;
    }

    public void addMutator(Method method, Object[] agrs) {
        if (!useMutableForCache) return;
        if (mutatorMethodCalls == null) mutatorMethodCalls = new HashSet<>();
        mutatorMethodCalls.add(new MethodCall(method, agrs));
    }

    public void addFieldValue(Field field, Object value) {
        if (fields == null) fields = new HashMap<>();
        fields.put(field, value);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CacheKey cacheKey)) return false;

        if (!Objects.equals(cacheMethodCall, cacheKey.cacheMethodCall)) return false;
        if (!Objects.equals(mutatorMethodCalls, cacheKey.mutatorMethodCalls)) return false;
        return Objects.equals(fields, cacheKey.fields);
    }

    @Override
    public int hashCode() {
        int result = cacheMethodCall != null ? cacheMethodCall.hashCode() : 0;
        result = 31 * result + (mutatorMethodCalls != null ? mutatorMethodCalls.hashCode() : 0);
        result = 31 * result + (fields != null ? fields.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "CacheKey.hashCode()='" + this.hashCode() + "'{" + "cacheMethodCall=" + cacheMethodCall + ", mutatorMethodCalls=" + mutatorMethodCalls + ", fields=" + fields + '}';
    }

    public Value getCacheValue() {
        if (cache == null) return null;
        return cache.get(this);
    }

    public void putCacheValue(Value value) {
        if (cache == null) {
            cache = new ConcurrentHashMap<>();//ConcurrentHashMap<>();IdentityHashMap
            StartCacheClearTread();
        }
        var keyForCache = new CacheKey(this);
        CacheObject.log("Сохраняем кэш для " + this);
        cache.put(keyForCache, value);
    }

    void StartCacheClearTread() {
        var th = new Thread(this);
        th.setDaemon(true);
        th.start();
    }

    @Override
    public void run() {
        var alive = true;
        while (alive) {
            cache.forEach((stateKey, value) -> {
                synchronized (value) {
                    if (value.timeExpired()) {
                        CacheObject.log("Удаление кеша " + stateKey);
                        cache.remove(stateKey);
                    }
                }
            });

            try {
                Thread.sleep(sleepTime);
            } catch (InterruptedException e) {
                alive = false;
            }
        }
    }
}
