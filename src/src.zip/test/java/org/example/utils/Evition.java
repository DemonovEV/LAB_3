package org.example.utils;

import lombok.Setter;
import org.example.utils.CacheObject.Cache;
import org.example.utils.CacheObject.Clock;
import org.junit.jupiter.api.Test;

import java.util.concurrent.BlockingQueue;

import static junit.framework.Assert.assertNotSame;
import static junit.framework.Assert.assertSame;

interface TestInterface {
    @Cache(1000)
    default Object Method1() {
        return new Object();
    }

    @Cache(1000)
    default Object Method2(Object arg1) {
        return new Object();
    }
}
/*
class TestClock implements Clock {
    long clock;

    public TestClock(long clock) {
        this.clock = clock;
    }

    @Override
    public long currentMillis() {
        return clock;
    }
}
*/

class TestBlockingClock implements Clock {
    private BlockingQueue<Long> time;
    private BlockingQueue<Boolean> ack;


    @Override public long currentTimeMillis() {
        try {
            var t = time.take();
            ack.put(true);
            return t;
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public void awaitConsume(long t) {
        try {
            time.put(t);
            ack.take();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
class TestClass implements TestInterface {
    @Setter
    int someValue = 0;
}

public class Evition {
    @Test
    void evictionCache() {
        // Ряд тестов для проерки кеширования кеширования

        TestClass ci = new TestClass();

        TestInterface proxy = CacheObject.cache(ci, false, false);

        var m1_v1 = proxy.Method1();
        var m2_v1 = proxy.Method2(500);

        var m1_v2 = proxy.Method1();
        var m2_v2 = proxy.Method2(500);
        assertSame(m1_v1, m1_v2); // ПРокси вернул то что было в кеше

        var m2_v3 = proxy.Method2(1500);// Вызываем Method2 с другим аргументом.
        var m1_v3 = proxy.Method1();

        assertNotSame(m2_v2, m2_v3); // Прокси должна вернуть новый объект. не то  же что раньше
        assertSame(m1_v2, m1_v3); // Убедимся что повторный вызов вернул  предыдущий кэш

        ci.setSomeValue(600); // Меняем некую переменную состояния.

        var m1_v4= proxy.Method1();
        var m2_v4 = proxy.Method2(1);
        // кеш лолжен обновится
        assertNotSame(m2_v3, m2_v4);
        assertNotSame(m1_v3, m1_v4);

    }

    @Test void evictionCacheClear() {
        var clock = new TestBlockingClock()();
        TestClass ci = new TestClass();

        TestInterface proxy = CacheObject.cache(ci, false, false,clock);

        var proxy = (TestIface) cached.proxy;
        var cleaner = cached.cleaner;

        var v1 = proxy.testMethod();
        var v2 = proxy.testMethod();

        assertEquals(v1, v2);

        var cleanupThread = new Thread(cleaner);
        cleanupThread.start();

        try {
            clock.awaitConsume(2200L);
            clock.awaitConsume(2200L);

            var v3 = proxy.testMethod();

            assertNotEquals(v2, v3);
        } finally {
            cleanupThread.interrupt();
        }
    }


}
